%-------------------------------------------------------------------------------
  %
  %  Filename       : L05_write_bpm.m
  %  Author         : Huang Leilei
  %  Status         : draft
  %  Created        : 2026-09-17
  %  Description    : script to write bpm
  %
%-------------------------------------------------------------------------------

% init
clear;
clc;
close all;

% read
img = imread('校园.jpg');
[sizY, sizX, ~] = size(img);

% write bpm
fp = fopen('校园_self.bmp', 'wb');
fwrite(fp, 'BM', 'uint8' );    % WORD  bfType;        // 2B，标识，固定0x4D42，字符"BM"；用来识别是BMP文件
fwrite(fp, ceil(sizX*3/4)*4*sizY + 14 + 40    ...
               , 'uint32');    % DWORD bfSize;        // 4B，整个BMP文件总字节大小
fwrite(fp, 0   , 'uint16');    % WORD  bfReserved1;   // 2B，保留，必须0
fwrite(fp, 0   , 'uint16');    % WORD  bfReserved2;   // 2B，保留，必须0
fwrite(fp, 14 + 40    ...
               , 'uint32');    % DWORD bfOffBits;     // 4B，偏移量：从文件开头到像素数据起始位置的字节偏移

fwrite(fp, 40  , 'uint32' );    % DWORD biSize;          //4B；本信息头本身大小=40
fwrite(fp, sizX, 'uint32' );    % LONG  biWidth;         //4B；图像宽度（像素）
fwrite(fp, sizY, 'uint32' );    % LONG  biHeight;        //4B；图像高度（像素）
fwrite(fp, 1   , 'uint16' );    % WORD  biPlanes;        //2B；色彩平面数，恒等于1
fwrite(fp, 24  , 'uint16' );    % WORD  biBitCount;      //2B；每个像素位数：1(二值),4,8,16,24(RGB),32(RGBA)
fwrite(fp, 0   , 'uint32' );    % DWORD biCompression;   //4B；压缩方式；0=BI_RGB无压缩；还有RLE压缩
fwrite(fp, ceil(sizX*3/4)*4*sizY ...
               , 'uint32' );    % DWORD biSizeImage;     //4B；图像像素数据部分总字节数，可以为0(24位时)
fwrite(fp, 0   , 'uint32' );    % LONG  biXPelsPerMeter; //4B；水平分辨率，每米像素
fwrite(fp, 0   , 'uint32' );    % LONG  biYPelsPerMeter; //4B；垂直分辨率
fwrite(fp, 0   , 'uint32' );    % DWORD biClrUsed;       //4B；实际使用调色板颜色数量；0代表全部
fwrite(fp, 0   , 'uint32' );    % DWORD biClrImportant;  //4B；重要颜色数量；0全部重要

% Sure, it will be much faster to adjust first and then write out.
for j = sizY:-1:1
    for i = 1:sizX
        for c = 3:-1:1
            fwrite(fp, img(j,i,c), 'uint8');
        end
    end
    for i = 1:(ceil(sizX*3/4)*4 - sizX*3)
        fwrite(fp, 0, 'uint8');
    end
end

fclose(fp);
