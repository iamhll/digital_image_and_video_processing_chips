%-------------------------------------------------------------------------------
  %
  %  Filename       : L05_format.m
  %  Author         : Huang Leilei
  %  Status         : draft
  %  Created        : 2026-09-17
  %  Description    : script to show format
  %
%-------------------------------------------------------------------------------

% init
clear;
clc;
close all;

% read
img = imread('校园.jpg');

% jpg
imwrite(img, '校园temp.jpg');
imgCodec = imread('校园temp.jpg');
fh = dir('校园temp.jpg');
fprintf("jpg: size: %4d KB, psnr: %.2f\n", round(fh.bytes / 1024), psnr(img, imgCodec));

% jpg
imwrite(img, '校园temp.jpg', 'quality', 100);
imgCodec = imread('校园temp.jpg');
fh = dir('校园temp.jpg');
fprintf("jpg: size: %d KB, psnr: %.2f\n", round(fh.bytes / 1024), psnr(img, imgCodec));

% png
imwrite(img, '校园.png');
imgCodec = imread('校园.png');
fh = dir('校园.png');
fprintf("png: size: %d KB, psnr: %.2f\n", round(fh.bytes / 1024), psnr(img, imgCodec));

% gif
[imgTmp, map] = rgb2ind(img, 256);
imwrite(imgTmp, map, '校园.gif', 'Loopcount', inf);
[imgTmp, map] = imread('校园.gif');
imgCodec = uint8(ind2rgb(imgTmp, map) * 255);
fh = dir('校园.gif');
fprintf("gif: size: %d KB, psnr: %.2f\n", round(fh.bytes / 1024), psnr(img, imgCodec));

% tif
imwrite(img, '校园.tif');
imgCodec = imread('校园.tif');
fh = dir('校园.tif');
fprintf("tif: size: %d KB, psnr: %.2f\n", round(fh.bytes / 1024), psnr(img, imgCodec));

% bmp
imwrite(img, '校园.bmp');
imgCodec = imread('校园.bmp');
fh = dir('校园.bmp');
fprintf("bpm: size: %d KB, psnr: %.2f\n", round(fh.bytes / 1024), psnr(img, imgCodec));
