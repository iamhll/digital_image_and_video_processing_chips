%-------------------------------------------------------------------------------
  %
  %  Filename       : runCodecWithMed.m
  %  Author         : Huang Leilei
  %  Status         : draft
  %  Created        : 2026-09-17
  %  Description    : script to run compress/decompressWithMed
  %
%-------------------------------------------------------------------------------

%% init
clear;
clc;
close all;
addpath("../主实验A")

%% read
datOri = imread("校园.jpg");
datOri = int16(datOri);

%% compress
datQuant = 1;
[datRes, datRec0] = compressWithMed(datOri, datQuant);

%% encode
HuffmanEnc(reshape(datOri, 1, [])    , 256, 0); fprintf("\n");
HuffmanEnc(reshape(datRes, 1, [])+256, 512, 0);

%% decompress
datRec1 = decompressWithMed(datRes);

%% show
% figure();
% imshow(uint8(datOri));
% figure();
% imshow(uint8(datRes));
% figure();
% imshow(uint8(datRec0));
% figure();
% imshow(uint8(datRec1));
psnr(uint8(datOri), uint8(datRec0))
isequal(datRec0, datRec1)

%% compress
datQuant = 4;
[datRes, datRec0] = compressWithMed(datOri, datQuant);

%% decompress
datRec1 = decompressWithMed(datRes);

%% show
% figure();
% imshow(uint8(datOri));
% figure();
% imshow(uint8(datRes));
% figure();
% imshow(uint8(datRec0));
% figure();
% imshow(uint8(datRec1));
psnr(uint8(datOri), uint8(datRec0))
isequal(datRec0, datRec1)
