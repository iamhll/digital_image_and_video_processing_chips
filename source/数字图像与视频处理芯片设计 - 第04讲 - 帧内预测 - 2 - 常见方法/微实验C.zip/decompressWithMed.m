function [datRec] = decompressWithMed(datRes)
    [sizY, sizX, numChn] = size(datRes);
    datRec = zeros(sizY, sizX, numChn);
    for idxChn = 1:numChn
        for idxY = 1:sizY
            for idxX = 1:sizX
                if idxX == 1 && idxY == 1
                    datRec(idxY,idxX,idxChn) = datRes(idxY,idxX,idxChn);
                else
                    if idxX == 1
                        datPreCur = datRec(idxY-1,idxX,idxChn);
                    elseif idxY == 1
                        datPreCur = datRec(idxY,idxX-1,idxChn);
                    else
                        datPreCur = predictWithMed(datRec(idxY,idxX-1,idxChn),datRec(idxY,idxX-1,idxChn),datRec(idxY-1,idxX-1,idxChn));
                    end
                    datRecCur = datPreCur + datRes(idxY,idxX,idxChn);
                    if datRecCur < 0
                        datRecCur = 0;
                    end
                    if datRecCur > 256
                        datRecCur = 256;
                    end
                    datRec(idxY,idxX,idxChn) = datRecCur;
                end
            end
        end
    end
end