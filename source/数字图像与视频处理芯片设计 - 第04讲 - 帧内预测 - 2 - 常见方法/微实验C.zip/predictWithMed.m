function datPre = predictWithMed(datA, datB, datC)
    datPre = median([datA, datB, datA+datB-datC]);
end
