function [datRes, datRec] = compressWithMed(datOri, datQuant)
    [sizY, sizX, numChn] = size(datOri);
    datRes = zeros(sizY, sizX, numChn);
    datRec = zeros(sizY, sizX, numChn);
    for idxChn = 1:numChn
        for idxY = 1:sizY
            for idxX = 1:sizX
                if idxX == 1 && idxY == 1
                    datRes(idxY,idxX,idxChn) = datOri(idxY,idxX,idxChn);
                    datRec(idxY,idxX,idxChn) = datOri(idxY,idxX,idxChn);
                else
                    if idxX == 1
                        datPreCur = datRec(idxY-1,idxX,idxChn);
                    elseif idxY == 1
                        datPreCur = datRec(idxY,idxX-1,idxChn);
                    else
                        datPreCur = predictWithMed(datRec(idxY,idxX-1,idxChn),datRec(idxY,idxX-1,idxChn),datRec(idxY-1,idxX-1,idxChn));
                    end
                    datResCur = datOri(idxY,idxX,idxChn) - datPreCur;
                    datResCur = round(datResCur / datQuant) * datQuant;
                    datRecCur = datPreCur + datResCur;
                    if datRecCur < 0
                        datRecCur = 0;
                    end
                    if datRecCur > 256
                        datRecCur = 256;
                    end
                    datRes(idxY,idxX,idxChn) = datResCur;
                    datRec(idxY,idxX,idxChn) = datRecCur;
                end
            end
        end
    end
end
