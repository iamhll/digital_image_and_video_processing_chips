//------------------------------------------------------------------------------
  //
  //  Filename       : main.cpp
  //  Author         : Huang Leilei
  //  Status         : phase 000
  //  Created        : 2026-09-17
  //  Description    : implementation of fw_dct_08
  //
//------------------------------------------------------------------------------

#include <cstdlib>
#include <ctime>
#include <iostream>
#include <fstream>
using namespace std;

static int16_t datCoeTf08[8][8] = {
    {64,  64,  64,  64,  64,  64,  64,  64},    // 0
    {89,  75,  50,  18, -18, -50, -75, -89},    // 1
    {83,  36, -36, -83, -83, -36,  36,  83},    // 2
    {75, -18, -89, -50,  50,  89,  18, -75},    // 3
    {64, -64, -64,  64,  64, -64, -64,  64},    // 4
    {50, -89,  18,  75, -75, -18,  89, -50},    // 5
    {36, -83,  83, -36, -36,  83, -83,  36},    // 6
    {18, -50,  75, -89,  89, -75,  50, -18}     // 7
};

void fwDct08Direct(const uint8_t src[8], int32_t dst[8])
{
    for (int j = 0; j < 8; ++j) {
        int32_t sum = 0;
        for (int i = 0; i < 8; ++i)
            sum += datCoeTf08[j][i] * src[i];
        dst[j] = sum;
    }
}

int main() {
    srand(time(nullptr));
    uint8_t src            [8];
    int32_t dstDirect      [8];
    ofstream fpIn ("FW_DCT_08_IN_S0I8F0.dat" );
    ofstream fpOut("FW_DCT_08_OUT_S1I18F0.dat");
    for (int j = 0; j < 100; ++j) {
        for (int i = 0; i < 8; ++i)
            src[i] = rand() % 256;
        fwDct08Direct(src, dstDirect);
        for (int i = 0; i < 8; ++i) {
            fpIn  << int32_t(src      [i]) << endl;
            fpOut <<         dstDirect[i]  << endl;
        }
    }
    fpIn.close();
    fpOut.close();
    return 0;
}
