g++ fw_dct_08.cpp -o fw_dct_08.o
./fw_dct_08.o

iverilog fw_dct_08.v tb_fw_dct_08.v -o tb_fw_dct_08.o
./tb_fw_dct_08.o

#gtkwave waveform.vcd

#rm *.o *.txt *.vcd
