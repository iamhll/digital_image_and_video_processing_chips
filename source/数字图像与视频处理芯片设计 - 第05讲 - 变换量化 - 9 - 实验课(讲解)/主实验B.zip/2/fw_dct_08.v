//------------------------------------------------------------------------------
  //
  //  Filename       : fw_dct_08.v
  //  Author         : Huang Leilei
  //  Status         : phase 000
  //  Created        : 2026-09-17
  //  Description    : [logic] to [do forward transform (08)]
  //
//------------------------------------------------------------------------------
  //
  //  ***    stage    reg number    reg operation        ***
  //  ***    0        8             V + V + V + V        ***
  //  ***    1        24            C * V                ***
  //  ***    2        8             V + V + V + V + C    ***
  //  ***                                                ***
  //  ***    C: const                                    ***
  //  ***    V: variable                                 ***
  //
//------------------------------------------------------------------------------

`include "define.vh"

module fw_dct_08(
  // global
  clk           ,
  rstn          ,
  // dat_i
  val_i         ,
  dat_i         ,
  // dat_o
  val_o         ,
  dat_o
);


//*** PARAMETER ****************************************************************

  // global
  parameter    DATA_IN_WD                      = 'd8                ;

  // local
  localparam   SIZE_BLK                        = 'd8                ;

  localparam   NUMB_INOUT                      = 'd8                ;
  localparam   NUMB_CLK_DELAY                  = 'd3                ;

  localparam   DATA_SCL_WD                     = 'd8                ;

  // derived
  localparam   DATA_AFT_SCL_WD                 = 'd1
                                               + DATA_IN_WD
                                               + DATA_SCL_WD        ;
  localparam   DATA_FUL_WD                     = DATA_AFT_SCL_WD
                                               + 'd4                ;
  localparam   DATA_OUT_WD                     = 'd1
                                               + DATA_IN_WD
                                               + 'd3
                                               + 'd6                ;


//*** INPUT/OUTPUT *************************************************************

  // global
  input                                        clk                  ;
  input                                        rstn                 ;

  // dat_i
  input                                        val_i                ;
  input       [DATA_IN_WD *NUMB_INOUT-1 :0]    dat_i                ;

  // dat_o
  output                                       val_o                ;
  output reg  [DATA_OUT_WD*NUMB_INOUT-1 :0]    dat_o                ;


//*** WIRE/REG *****************************************************************

  // global
  reg         [NUMB_CLK_DELAY        -1 :0]    val_delay_r          ;

  wire        [DATA_IN_WD            -1 :0]    dat_in_0_w           ;
  wire        [DATA_IN_WD            -1 :0]    dat_in_1_w           ;
  wire        [DATA_IN_WD            -1 :0]    dat_in_2_w           ;
  wire        [DATA_IN_WD            -1 :0]    dat_in_3_w           ;
  wire        [DATA_IN_WD            -1 :0]    dat_in_4_w           ;
  wire        [DATA_IN_WD            -1 :0]    dat_in_5_w           ;
  wire        [DATA_IN_WD            -1 :0]    dat_in_6_w           ;
  wire        [DATA_IN_WD            -1 :0]    dat_in_7_w           ;

  // stage 0
  reg  signed [DATA_IN_WD+1+1        -1 :0]    dat_o_0_d0_r         ;
  reg  signed [DATA_IN_WD+1+1        -1 :0]    dat_o_1_d0_r         ;
  reg  signed [DATA_IN_WD+1+1        -1 :0]    dat_o_2_d0_r         ;
  reg  signed [DATA_IN_WD+1+1        -1 :0]    dat_o_3_d0_r         ;

  reg  signed [DATA_IN_WD+1+2        -1 :0]    dat_ee_0_d0_r        ;
  reg  signed [DATA_IN_WD+1+2        -1 :0]    dat_ee_1_d0_r        ;

  reg  signed [DATA_IN_WD+1+2        -1 :0]    dat_eo_0_d0_r        ;
  reg  signed [DATA_IN_WD+1+2        -1 :0]    dat_eo_1_d0_r        ;

  wire signed [DATA_IN_WD+1+1        -1 :0]    dat_e_0_w            ;
  wire signed [DATA_IN_WD+1+1        -1 :0]    dat_e_1_w            ;
  wire signed [DATA_IN_WD+1+1        -1 :0]    dat_e_2_w            ;
  wire signed [DATA_IN_WD+1+1        -1 :0]    dat_e_3_w            ;

  wire signed [DATA_IN_WD+1+1        -1 :0]    dat_o_0_w            ;
  wire signed [DATA_IN_WD+1+1        -1 :0]    dat_o_1_w            ;
  wire signed [DATA_IN_WD+1+1        -1 :0]    dat_o_2_w            ;
  wire signed [DATA_IN_WD+1+1        -1 :0]    dat_o_3_w            ;

  // stage 1
  reg  signed [DATA_AFT_SCL_WD+2     -1 :0]    dat_aft_scl_0_0_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+2     -1 :0]    dat_aft_scl_0_1_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+2     -1 :0]    dat_aft_scl_4_0_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+2     -1 :0]    dat_aft_scl_4_1_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+2     -1 :0]    dat_aft_scl_2_0_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+2     -1 :0]    dat_aft_scl_2_1_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+2     -1 :0]    dat_aft_scl_6_0_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+2     -1 :0]    dat_aft_scl_6_1_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_1_0_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_1_1_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_1_2_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_1_3_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_3_0_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_3_1_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_3_2_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_3_3_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_5_0_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_5_1_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_5_2_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_5_3_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_7_0_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_7_1_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_7_2_d1_r ;
  reg  signed [DATA_AFT_SCL_WD+1     -1 :0]    dat_aft_scl_7_3_d1_r ;

  // output (dat_o)
  wire signed [DATA_OUT_WD           -1 :0]    dat_out_0_d1_w       ;
  wire signed [DATA_OUT_WD           -1 :0]    dat_out_1_d1_w       ;
  wire signed [DATA_OUT_WD           -1 :0]    dat_out_2_d1_w       ;
  wire signed [DATA_OUT_WD           -1 :0]    dat_out_3_d1_w       ;
  wire signed [DATA_OUT_WD           -1 :0]    dat_out_4_d1_w       ;
  wire signed [DATA_OUT_WD           -1 :0]    dat_out_5_d1_w       ;
  wire signed [DATA_OUT_WD           -1 :0]    dat_out_6_d1_w       ;
  wire signed [DATA_OUT_WD           -1 :0]    dat_out_7_d1_w       ;
  wire signed [DATA_FUL_WD           -1 :0]    dat_ful_0_d1_w       ;
  wire signed [DATA_FUL_WD           -1 :0]    dat_ful_1_d1_w       ;
  wire signed [DATA_FUL_WD           -1 :0]    dat_ful_2_d1_w       ;
  wire signed [DATA_FUL_WD           -1 :0]    dat_ful_3_d1_w       ;
  wire signed [DATA_FUL_WD           -1 :0]    dat_ful_4_d1_w       ;
  wire signed [DATA_FUL_WD           -1 :0]    dat_ful_5_d1_w       ;
  wire signed [DATA_FUL_WD           -1 :0]    dat_ful_6_d1_w       ;
  wire signed [DATA_FUL_WD           -1 :0]    dat_ful_7_d1_w       ;


//*** MAIN BODY ****************************************************************
//--- GLOBAL ---------------------------
  // val_delay_r
  always @(posedge clk or negedge rstn ) begin
    if( !rstn ) begin
      val_delay_r <= 'd0 ;
    end
    else begin
      val_delay_r <= { val_delay_r ,val_i };
    end
  end

  // dat_in_0_w, dat_in_1_w, dat_in_2_w, dat_in_3_w
  // dat_in_4_w, dat_in_5_w, dat_in_6_w, dat_in_7_w
  assign { dat_in_0_w
          ,dat_in_1_w
          ,dat_in_2_w
          ,dat_in_3_w
          ,dat_in_4_w
          ,dat_in_5_w
          ,dat_in_6_w
          ,dat_in_7_w
  } = dat_i ;


//--- STAGE 0 --------------------------
  // dat_o_0_d0_r, dat_o_1_d0_r, dat_o_2_d0_r, dat_o_3_d0_r
  always @(posedge clk or negedge rstn ) begin
    if( !rstn ) begin
      dat_o_0_d0_r <= 'd0 ;
      dat_o_1_d0_r <= 'd0 ;
      dat_o_2_d0_r <= 'd0 ;
      dat_o_3_d0_r <= 'd0 ;
    end
    else begin
      if( val_i ) begin
        dat_o_0_d0_r <= dat_o_0_w ;
        dat_o_1_d0_r <= dat_o_1_w ;
        dat_o_2_d0_r <= dat_o_2_w ;
        dat_o_3_d0_r <= dat_o_3_w ;
      end
    end
  end

  // dat_ee_0_d0_r, dat_ee_1_d0_r
  always @(posedge clk or negedge rstn ) begin
    if( !rstn ) begin
      dat_ee_0_d0_r <= 'd0 ;
      dat_ee_1_d0_r <= 'd0 ;
    end
    else begin
      if( val_i ) begin
        dat_ee_0_d0_r <= dat_e_0_w + dat_e_3_w ;
        dat_ee_1_d0_r <= dat_e_1_w + dat_e_2_w ;
      end
    end
  end

  // dat_eo_0_d0_r, dat_eo_1_d0_r
  always @(posedge clk or negedge rstn ) begin
    if( !rstn ) begin
      dat_eo_0_d0_r <= 'd0 ;
      dat_eo_1_d0_r <= 'd0 ;
    end
    else begin
      if( val_i ) begin
        dat_eo_0_d0_r <= dat_e_0_w - dat_e_3_w ;
        dat_eo_1_d0_r <= dat_e_1_w - dat_e_2_w ;
      end
    end
  end

  // dat_e_0_w, dat_e_1_w, dat_e_2_w, dat_e_3_w
  assign dat_e_0_w = $signed({1'b0,dat_in_0_w}) + $signed({1'b0,dat_in_7_w}) ;
  assign dat_e_1_w = $signed({1'b0,dat_in_1_w}) + $signed({1'b0,dat_in_6_w}) ;
  assign dat_e_2_w = $signed({1'b0,dat_in_2_w}) + $signed({1'b0,dat_in_5_w}) ;
  assign dat_e_3_w = $signed({1'b0,dat_in_3_w}) + $signed({1'b0,dat_in_4_w}) ;

  // dat_o_0_w, dat_o_1_w, dat_o_2_w, dat_o_3_w
  assign dat_o_0_w = $signed({1'b0,dat_in_0_w}) - $signed({1'b0,dat_in_7_w}) ;
  assign dat_o_1_w = $signed({1'b0,dat_in_1_w}) - $signed({1'b0,dat_in_6_w}) ;
  assign dat_o_2_w = $signed({1'b0,dat_in_2_w}) - $signed({1'b0,dat_in_5_w}) ;
  assign dat_o_3_w = $signed({1'b0,dat_in_3_w}) - $signed({1'b0,dat_in_4_w}) ;


//--- STAGE 1 --------------------------
  // dat_aft_scl_0_0_d1_r, dat_aft_scl_0_1_d1_r
  // dat_aft_scl_1_0_d1_r, dat_aft_scl_1_1_d1_r, dat_aft_scl_1_2_d1_r, dat_aft_scl_1_3_d1_r
  // dat_aft_scl_2_0_d1_r, dat_aft_scl_2_1_d1_r
  // dat_aft_scl_3_0_d1_r, dat_aft_scl_3_1_d1_r, dat_aft_scl_3_2_d1_r, dat_aft_scl_3_3_d1_r
  // dat_aft_scl_4_0_d1_r, dat_aft_scl_4_1_d1_r
  // dat_aft_scl_5_0_d1_r, dat_aft_scl_5_1_d1_r, dat_aft_scl_5_2_d1_r, dat_aft_scl_5_3_d1_r
  // dat_aft_scl_6_0_d1_r, dat_aft_scl_6_1_d1_r
  // dat_aft_scl_7_0_d1_r, dat_aft_scl_7_1_d1_r, dat_aft_scl_7_2_d1_r, dat_aft_scl_7_3_d1_r
  always @(posedge clk or negedge rstn ) begin
    if( !rstn ) begin
      dat_aft_scl_0_0_d1_r <= 'd0 ;
      dat_aft_scl_0_1_d1_r <= 'd0 ;
      dat_aft_scl_4_0_d1_r <= 'd0 ;
      dat_aft_scl_4_1_d1_r <= 'd0 ;
      dat_aft_scl_2_0_d1_r <= 'd0 ;
      dat_aft_scl_2_1_d1_r <= 'd0 ;
      dat_aft_scl_6_0_d1_r <= 'd0 ;
      dat_aft_scl_6_1_d1_r <= 'd0 ;
      dat_aft_scl_1_0_d1_r <= 'd0 ;
      dat_aft_scl_1_1_d1_r <= 'd0 ;
      dat_aft_scl_1_2_d1_r <= 'd0 ;
      dat_aft_scl_1_3_d1_r <= 'd0 ;
      dat_aft_scl_3_0_d1_r <= 'd0 ;
      dat_aft_scl_3_1_d1_r <= 'd0 ;
      dat_aft_scl_3_2_d1_r <= 'd0 ;
      dat_aft_scl_3_3_d1_r <= 'd0 ;
      dat_aft_scl_5_0_d1_r <= 'd0 ;
      dat_aft_scl_5_1_d1_r <= 'd0 ;
      dat_aft_scl_5_2_d1_r <= 'd0 ;
      dat_aft_scl_5_3_d1_r <= 'd0 ;
      dat_aft_scl_7_0_d1_r <= 'd0 ;
      dat_aft_scl_7_1_d1_r <= 'd0 ;
      dat_aft_scl_7_2_d1_r <= 'd0 ;
      dat_aft_scl_7_3_d1_r <= 'd0 ;
    end
    else begin
      if( val_delay_r[0] ) begin
        dat_aft_scl_0_0_d1_r <= dat_ee_0_d0_r *  'sd64 ;
        dat_aft_scl_0_1_d1_r <= dat_ee_1_d0_r *  'sd64 ;
        dat_aft_scl_4_0_d1_r <= dat_ee_0_d0_r *  'sd64 ;
        dat_aft_scl_4_1_d1_r <= dat_ee_1_d0_r * -'sd64 ;
        dat_aft_scl_2_0_d1_r <= dat_eo_0_d0_r *  'sd83 ;
        dat_aft_scl_2_1_d1_r <= dat_eo_1_d0_r *  'sd36 ;
        dat_aft_scl_6_0_d1_r <= dat_eo_0_d0_r *  'sd36 ;
        dat_aft_scl_6_1_d1_r <= dat_eo_1_d0_r * -'sd83 ;
        dat_aft_scl_1_0_d1_r <= dat_o_0_d0_r  *  'sd89 ;
        dat_aft_scl_1_1_d1_r <= dat_o_1_d0_r  *  'sd75 ;
        dat_aft_scl_1_2_d1_r <= dat_o_2_d0_r  *  'sd50 ;
        dat_aft_scl_1_3_d1_r <= dat_o_3_d0_r  *  'sd18 ;
        dat_aft_scl_3_0_d1_r <= dat_o_0_d0_r  *  'sd75 ;
        dat_aft_scl_3_1_d1_r <= dat_o_1_d0_r  * -'sd18 ;
        dat_aft_scl_3_2_d1_r <= dat_o_2_d0_r  * -'sd89 ;
        dat_aft_scl_3_3_d1_r <= dat_o_3_d0_r  * -'sd50 ;
        dat_aft_scl_5_0_d1_r <= dat_o_0_d0_r  *  'sd50 ;
        dat_aft_scl_5_1_d1_r <= dat_o_1_d0_r  * -'sd89 ;
        dat_aft_scl_5_2_d1_r <= dat_o_2_d0_r  *  'sd18 ;
        dat_aft_scl_5_3_d1_r <= dat_o_3_d0_r  *  'sd75 ;
        dat_aft_scl_7_0_d1_r <= dat_o_0_d0_r  *  'sd18 ;
        dat_aft_scl_7_1_d1_r <= dat_o_1_d0_r  * -'sd50 ;
        dat_aft_scl_7_2_d1_r <= dat_o_2_d0_r  *  'sd75 ;
        dat_aft_scl_7_3_d1_r <= dat_o_3_d0_r  * -'sd89 ;
      end
    end
  end


//--- OUTPUT (dat_o) -------------------
  // val_o
  assign val_o = val_delay_r[2] ;

  // dat_o
  always @(posedge clk or negedge rstn ) begin
    if( !rstn ) begin
      dat_o <= 'd0 ;
    end
    else begin
      if( val_delay_r[1] ) begin
        dat_o <= { dat_out_0_d1_w
                  ,dat_out_1_d1_w
                  ,dat_out_2_d1_w
                  ,dat_out_3_d1_w
                  ,dat_out_4_d1_w
                  ,dat_out_5_d1_w
                  ,dat_out_6_d1_w
                  ,dat_out_7_d1_w
        };
      end
    end
  end

  // dat_out_0_d1_w, dat_out_1_d1_w, dat_out_2_d1_w, dat_out_3_d1_w
  // dat_out_4_d1_w, dat_out_5_d1_w, dat_out_6_d1_w, dat_out_7_d1_w
  assign dat_out_0_d1_w = dat_ful_0_d1_w ;
  assign dat_out_1_d1_w = dat_ful_1_d1_w ;
  assign dat_out_2_d1_w = dat_ful_2_d1_w ;
  assign dat_out_3_d1_w = dat_ful_3_d1_w ;
  assign dat_out_4_d1_w = dat_ful_4_d1_w ;
  assign dat_out_5_d1_w = dat_ful_5_d1_w ;
  assign dat_out_6_d1_w = dat_ful_6_d1_w ;
  assign dat_out_7_d1_w = dat_ful_7_d1_w ;

  // dat_ful_0_d1_w, dat_ful_1_d1_w, dat_ful_2_d1_w, dat_ful_3_d1_w
  // dat_ful_4_d1_w, dat_ful_5_d1_w, dat_ful_6_d1_w, dat_ful_7_d1_w
  assign dat_ful_0_d1_w = dat_aft_scl_0_0_d1_r + dat_aft_scl_0_1_d1_r ;
  assign dat_ful_1_d1_w = dat_aft_scl_1_0_d1_r + dat_aft_scl_1_1_d1_r + dat_aft_scl_1_2_d1_r + dat_aft_scl_1_3_d1_r ;
  assign dat_ful_2_d1_w = dat_aft_scl_2_0_d1_r + dat_aft_scl_2_1_d1_r ;
  assign dat_ful_3_d1_w = dat_aft_scl_3_0_d1_r + dat_aft_scl_3_1_d1_r + dat_aft_scl_3_2_d1_r + dat_aft_scl_3_3_d1_r ;
  assign dat_ful_4_d1_w = dat_aft_scl_4_0_d1_r + dat_aft_scl_4_1_d1_r ;
  assign dat_ful_5_d1_w = dat_aft_scl_5_0_d1_r + dat_aft_scl_5_1_d1_r + dat_aft_scl_5_2_d1_r + dat_aft_scl_5_3_d1_r ;
  assign dat_ful_6_d1_w = dat_aft_scl_6_0_d1_r + dat_aft_scl_6_1_d1_r ;
  assign dat_ful_7_d1_w = dat_aft_scl_7_0_d1_r + dat_aft_scl_7_1_d1_r + dat_aft_scl_7_2_d1_r + dat_aft_scl_7_3_d1_r ;


//*** DEBUG ********************************************************************

  `ifdef SIM_KNOB_DBG_CDC

  `endif

endmodule
