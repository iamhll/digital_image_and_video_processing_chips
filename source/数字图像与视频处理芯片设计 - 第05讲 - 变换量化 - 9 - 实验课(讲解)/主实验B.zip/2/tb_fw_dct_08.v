//------------------------------------------------------------------------------
  //
  //  Filename       : tb_fw_dct_08.v
  //  Author         : Huang Leilei
  //  Status         : draft
  //  Created        : 2026-09-17
  //  Description    : [testbench] for [fw_dct_08]
  //
//------------------------------------------------------------------------------

`include "define.vh"

//--- GLOBAL ---------------------------
  `define SIM_KNOB_WAVEFORM_VCD     1
  `define SIM_DATA_WAVEFORM_TIME    0


//--- LOCAL ----------------------------
  // SIM
  `define SIM_DATA_PRD_CLK                    10.000

  `define SIM_CSTR_FILE_CHKI_FW_DCT_08_DAT    "FW_DCT_08_IN_S0I8F0.dat"

  `define SIM_CSTR_FILE_CHKO_FW_DCT_08_DAT    "FW_DCT_08_OUT_S1I18F0.dat"

  `define SIM_CSTR_FILE_WAVE_VCD              "waveform.vcd"


module tb_fw_dct_08 ;


//*** PARAMETER ****************************************************************

  // local
  localparam   DATA_IN_WD               = 'd8           ;
  localparam   DATA_OUT_WD              = 'd1
                                        + DATA_IN_WD
                                        + 'd3
                                        + 'd6           ;
  localparam   NUMB_INOUT               = 'd8           ;


//*** INPUT/OUTPUT *************************************************************

  // global
  reg                                   clk             ;
  reg                                   rstn            ;

  // dat_i
  reg                                   val_i           ;
  reg  [DATA_IN_WD *NUMB_INOUT-1 :0]    dat_i           ;

  // dat_o
  wire                                  val_o           ;
  wire [DATA_OUT_WD*NUMB_INOUT-1 :0]    dat_o           ;


//*** WIRE/REG *****************************************************************

  // sim
  integer                               sim_fpt_in      ;
  integer                               sim_fpt_out     ;
  integer                               sim_idx_in      ;
  integer                               sim_idx_out     ;
  integer                               sim_tmp         ;
  reg  [DATA_IN_WD            -1 :0]    sim_dat_in      ;
  reg  [DATA_OUT_WD           -1 :0]    sim_dat_out     ;
  reg  [DATA_OUT_WD*NUMB_INOUT-1 :0]    sim_dat_out_ful ;

  // dut
  reg                                   dut_val         ;
  reg  [DATA_OUT_WD*NUMB_INOUT-1 :0]    dut_dat         ;


//*** MAIN BODY ****************************************************************
//--- PROCESS --------------------------
  // clk
  initial begin
    clk = 'd0 ;
    forever begin
      #( `SIM_DATA_PRD_CLK / 'd2 );
      clk = ! clk ;
    end
  end

  // rstn
  initial begin
    rstn = 'd0 ;
    #( 5 * `SIM_DATA_PRD_CLK );
    @(negedge clk );
    rstn = 'd1 ;
  end

  // main
  initial begin
    // init
    val_i = 'd0 ;
    dat_i = 'd0 ;

    // delay
    #( 5 * `SIM_DATA_PRD_CLK );

    // log
    $display( "\n\n*** CHECK BEGIN ! ***\n" );

    // delay
    #( 5 * `SIM_DATA_PRD_CLK );
    $display( "" );

    // open files
    sim_fpt_in = $fopen( `SIM_CSTR_FILE_CHKI_FW_DCT_08_DAT ,"r" );

    // set
    sim_tmp = 'd1 ;
    while( sim_tmp != -'sd1 ) begin
      @(negedge clk );
      val_i = 'd1 ;
      for( sim_idx_in = 0; sim_idx_in < 'd8 ;sim_idx_in = sim_idx_in + 'd1 ) begin
        sim_tmp = $fscanf( sim_fpt_in ,"%d" ,sim_dat_in );
        dat_i = { dat_i ,sim_dat_in };
        if( sim_tmp == -'sd1 ) begin
          val_i = 'd0 ;
        end
      end
    end
    @(negedge clk );
    val_i = 'd0 ;
    dat_i = $random ;

    // delay
    #( 5 * `SIM_DATA_PRD_CLK );

    // post
    val_i = 'd0 ;
    dat_i = 'd0 ;

    // log
    #( 1000 * `SIM_DATA_PRD_CLK );
    $display( "\n\n*** CHECK END ! ***\n" );
    $finish;
  end

  // checker
  initial begin
    // log info
    #( 10 * `SIM_DATA_PRD_CLK );
    $display( "\t\t function check to dat_o is on!" );

    // open files
    sim_fpt_out = $fopen( `SIM_CSTR_FILE_CHKO_FW_DCT_08_DAT ,"r" );

    // core loop
    forever begin
      // wait
      @(negedge clk );

      // dut_val
      dut_val = val_o ;

      // if valid
      if( dut_val ) begin
        // dut_*
        dut_dat = dat_o ;

        // sim_*
        for( sim_idx_in = 0; sim_idx_in < 'd8 ;sim_idx_in = sim_idx_in + 'd1 ) begin
          sim_tmp = $fscanf( sim_fpt_out ,"%d" ,sim_dat_out );
          sim_dat_out_ful = { sim_dat_out_ful ,sim_dat_out };
        end

        // check
        if( dut_dat !== sim_dat_out_ful ) begin
          $display("\n\t ERROR: at %08d ns, dat_o should be %x, however is %x!\n"
            ,$time
            ,sim_dat_out_ful
            ,dut_dat
          );
          #( 1000 * `SIM_DATA_PRD_CLK );
          $finish ;
        end
      end
    end
  end


//--- INSTANTIATION --------------------
  // begin of DUT
    fw_dct_08 dut(
      // global
      .clk      ( clk      ),
      .rstn     ( rstn     ),
      // dat_i
      .val_i    ( val_i    ),
      .dat_i    ( dat_i    ),
      // dat_o
      .val_o    ( val_o    ),
      .dat_o    ( dat_o    )
    );
  // end   of DUT


//--- WAVEFORM DUMP --------------------
  // vcd
  `ifdef SIM_KNOB_WAVEFORM_VCD
    initial begin
      if( `SIM_KNOB_WAVEFORM_VCD ) begin
        #`SIM_DATA_WAVEFORM_TIME ;
        $dumpfile( `SIM_CSTR_FILE_WAVE_VCD );
        $dumpvars( 'd0, tb_fw_dct_08 );
        #( 10 * `SIM_DATA_PRD_CLK );
        $display( "\t\t dump (vcd) to this test is on!" );
      end
    end
  `endif

endmodule
