//------------------------------------------------------------------------------
    //
    //  Filename       : main.cpp
    //  Author         : Huang Leilei
    //  Status         : phase 000
    //  Created        : 2026-09-17
    //  Description    : comparison of difference fwDct16 implementations
    //
//------------------------------------------------------------------------------

#include <cstdlib>
#include <ctime>
#include <iostream>
using namespace std;

static int16_t datCoeTf16[16][16] = {
    {64,  64,  64,  64,  64,  64,  64,  64,  64,  64,  64,  64,  64,  64,  64,  64},    // 0
    {90,  87,  80,  70,  57,  43,  25,   9,  -9, -25, -43, -57, -70, -80, -87, -90},    // 1
    {89,  75,  50,  18, -18, -50, -75, -89, -89, -75, -50, -18,  18,  50,  75,  89},    // 2
    {87,  57,   9, -43, -80, -90, -70, -25,  25,  70,  90,  80,  43,  -9, -57, -87},    // 3
    {83,  36, -36, -83, -83, -36,  36,  83,  83,  36, -36, -83, -83, -36,  36,  83},    // 4
    {80,   9, -70, -87, -25,  57,  90,  43, -43, -90, -57,  25,  87,  70,  -9, -80},    // 5
    {75, -18, -89, -50,  50,  89,  18, -75, -75,  18,  89,  50, -50, -89, -18,  75},    // 6
    {70, -43, -87,   9,  90,  25, -80, -57,  57,  80, -25, -90,  -9,  87,  43, -70},    // 7
    {64, -64, -64,  64,  64, -64, -64,  64,  64, -64, -64,  64,  64, -64, -64,  64},    // 8
    {57, -80, -25,  90,  -9, -87,  43,  70, -70, -43,  87,   9, -90,  25,  80, -57},    // 9
    {50, -89,  18,  75, -75, -18,  89, -50, -50,  89, -18, -75,  75,  18, -89,  50},    // a
    {43, -90,  57,  25, -87,  70,   9, -80,  80,  -9, -70,  87, -25, -57,  90, -43},    // b
    {36, -83,  83, -36, -36,  83, -83,  36,  36, -83,  83, -36, -36,  83, -83,  36},    // c
    {25, -70,  90, -80,  43,   9, -57,  87, -87,  57,  -9, -43,  80, -90,  70, -25},    // d
    {18, -50,  75, -89,  89, -75,  50, -18, -18,  50, -75,  89, -89,  75, -50,  18},    // e
    { 9, -25,  43, -57,  70, -80,  87, -90,  90, -87,  80, -70,  57, -43,  25,  -9}     // f
};

void fwDct16Direct(const uint8_t src[16], int32_t dst[16])
{
    for (int j = 0; j < 16; ++j) {
        int32_t sum = 0;
        for (int i = 0; i < 16; ++i)
            sum += datCoeTf16[j][i] * src[i];
        dst[j] = sum;
    }
}

void fwDct16DirectUnroll(const uint8_t src[16], int32_t dst[16])
{
    dst[ 0] = datCoeTf16[ 0][ 0] * src[ 0]
        +     datCoeTf16[ 0][ 1] * src[ 1]
        +     datCoeTf16[ 0][ 2] * src[ 2]
        +     datCoeTf16[ 0][ 3] * src[ 3]
        +     datCoeTf16[ 0][ 4] * src[ 4]
        +     datCoeTf16[ 0][ 5] * src[ 5]
        +     datCoeTf16[ 0][ 6] * src[ 6]
        +     datCoeTf16[ 0][ 7] * src[ 7]
        +     datCoeTf16[ 0][ 8] * src[ 8]
        +     datCoeTf16[ 0][ 9] * src[ 9]
        +     datCoeTf16[ 0][10] * src[10]
        +     datCoeTf16[ 0][11] * src[11]
        +     datCoeTf16[ 0][12] * src[12]
        +     datCoeTf16[ 0][13] * src[13]
        +     datCoeTf16[ 0][14] * src[14]
        +     datCoeTf16[ 0][15] * src[15]
    ;
    dst[ 1] = datCoeTf16[ 1][ 0] * src[ 0]
        +     datCoeTf16[ 1][ 1] * src[ 1]
        +     datCoeTf16[ 1][ 2] * src[ 2]
        +     datCoeTf16[ 1][ 3] * src[ 3]
        +     datCoeTf16[ 1][ 4] * src[ 4]
        +     datCoeTf16[ 1][ 5] * src[ 5]
        +     datCoeTf16[ 1][ 6] * src[ 6]
        +     datCoeTf16[ 1][ 7] * src[ 7]
        +     datCoeTf16[ 1][ 8] * src[ 8]
        +     datCoeTf16[ 1][ 9] * src[ 9]
        +     datCoeTf16[ 1][10] * src[10]
        +     datCoeTf16[ 1][11] * src[11]
        +     datCoeTf16[ 1][12] * src[12]
        +     datCoeTf16[ 1][13] * src[13]
        +     datCoeTf16[ 1][14] * src[14]
        +     datCoeTf16[ 1][15] * src[15]
    ;
    dst[ 2] = datCoeTf16[ 2][ 0] * src[ 0]
        +     datCoeTf16[ 2][ 1] * src[ 1]
        +     datCoeTf16[ 2][ 2] * src[ 2]
        +     datCoeTf16[ 2][ 3] * src[ 3]
        +     datCoeTf16[ 2][ 4] * src[ 4]
        +     datCoeTf16[ 2][ 5] * src[ 5]
        +     datCoeTf16[ 2][ 6] * src[ 6]
        +     datCoeTf16[ 2][ 7] * src[ 7]
        +     datCoeTf16[ 2][ 8] * src[ 8]
        +     datCoeTf16[ 2][ 9] * src[ 9]
        +     datCoeTf16[ 2][10] * src[10]
        +     datCoeTf16[ 2][11] * src[11]
        +     datCoeTf16[ 2][12] * src[12]
        +     datCoeTf16[ 2][13] * src[13]
        +     datCoeTf16[ 2][14] * src[14]
        +     datCoeTf16[ 2][15] * src[15]
    ;
    dst[ 3] = datCoeTf16[ 3][ 0] * src[ 0]
        +     datCoeTf16[ 3][ 1] * src[ 1]
        +     datCoeTf16[ 3][ 2] * src[ 2]
        +     datCoeTf16[ 3][ 3] * src[ 3]
        +     datCoeTf16[ 3][ 4] * src[ 4]
        +     datCoeTf16[ 3][ 5] * src[ 5]
        +     datCoeTf16[ 3][ 6] * src[ 6]
        +     datCoeTf16[ 3][ 7] * src[ 7]
        +     datCoeTf16[ 3][ 8] * src[ 8]
        +     datCoeTf16[ 3][ 9] * src[ 9]
        +     datCoeTf16[ 3][10] * src[10]
        +     datCoeTf16[ 3][11] * src[11]
        +     datCoeTf16[ 3][12] * src[12]
        +     datCoeTf16[ 3][13] * src[13]
        +     datCoeTf16[ 3][14] * src[14]
        +     datCoeTf16[ 3][15] * src[15]
    ;
    dst[ 4] = datCoeTf16[ 4][ 0] * src[ 0]
        +     datCoeTf16[ 4][ 1] * src[ 1]
        +     datCoeTf16[ 4][ 2] * src[ 2]
        +     datCoeTf16[ 4][ 3] * src[ 3]
        +     datCoeTf16[ 4][ 4] * src[ 4]
        +     datCoeTf16[ 4][ 5] * src[ 5]
        +     datCoeTf16[ 4][ 6] * src[ 6]
        +     datCoeTf16[ 4][ 7] * src[ 7]
        +     datCoeTf16[ 4][ 8] * src[ 8]
        +     datCoeTf16[ 4][ 9] * src[ 9]
        +     datCoeTf16[ 4][10] * src[10]
        +     datCoeTf16[ 4][11] * src[11]
        +     datCoeTf16[ 4][12] * src[12]
        +     datCoeTf16[ 4][13] * src[13]
        +     datCoeTf16[ 4][14] * src[14]
        +     datCoeTf16[ 4][15] * src[15]
    ;
    dst[ 5] = datCoeTf16[ 5][ 0] * src[ 0]
        +     datCoeTf16[ 5][ 1] * src[ 1]
        +     datCoeTf16[ 5][ 2] * src[ 2]
        +     datCoeTf16[ 5][ 3] * src[ 3]
        +     datCoeTf16[ 5][ 4] * src[ 4]
        +     datCoeTf16[ 5][ 5] * src[ 5]
        +     datCoeTf16[ 5][ 6] * src[ 6]
        +     datCoeTf16[ 5][ 7] * src[ 7]
        +     datCoeTf16[ 5][ 8] * src[ 8]
        +     datCoeTf16[ 5][ 9] * src[ 9]
        +     datCoeTf16[ 5][10] * src[10]
        +     datCoeTf16[ 5][11] * src[11]
        +     datCoeTf16[ 5][12] * src[12]
        +     datCoeTf16[ 5][13] * src[13]
        +     datCoeTf16[ 5][14] * src[14]
        +     datCoeTf16[ 5][15] * src[15]
    ;
    dst[ 6] = datCoeTf16[ 6][ 0] * src[ 0]
        +     datCoeTf16[ 6][ 1] * src[ 1]
        +     datCoeTf16[ 6][ 2] * src[ 2]
        +     datCoeTf16[ 6][ 3] * src[ 3]
        +     datCoeTf16[ 6][ 4] * src[ 4]
        +     datCoeTf16[ 6][ 5] * src[ 5]
        +     datCoeTf16[ 6][ 6] * src[ 6]
        +     datCoeTf16[ 6][ 7] * src[ 7]
        +     datCoeTf16[ 6][ 8] * src[ 8]
        +     datCoeTf16[ 6][ 9] * src[ 9]
        +     datCoeTf16[ 6][10] * src[10]
        +     datCoeTf16[ 6][11] * src[11]
        +     datCoeTf16[ 6][12] * src[12]
        +     datCoeTf16[ 6][13] * src[13]
        +     datCoeTf16[ 6][14] * src[14]
        +     datCoeTf16[ 6][15] * src[15]
    ;
    dst[ 7] = datCoeTf16[ 7][ 0] * src[ 0]
        +     datCoeTf16[ 7][ 1] * src[ 1]
        +     datCoeTf16[ 7][ 2] * src[ 2]
        +     datCoeTf16[ 7][ 3] * src[ 3]
        +     datCoeTf16[ 7][ 4] * src[ 4]
        +     datCoeTf16[ 7][ 5] * src[ 5]
        +     datCoeTf16[ 7][ 6] * src[ 6]
        +     datCoeTf16[ 7][ 7] * src[ 7]
        +     datCoeTf16[ 7][ 8] * src[ 8]
        +     datCoeTf16[ 7][ 9] * src[ 9]
        +     datCoeTf16[ 7][10] * src[10]
        +     datCoeTf16[ 7][11] * src[11]
        +     datCoeTf16[ 7][12] * src[12]
        +     datCoeTf16[ 7][13] * src[13]
        +     datCoeTf16[ 7][14] * src[14]
        +     datCoeTf16[ 7][15] * src[15]
    ;
    dst[ 8] = datCoeTf16[ 8][ 0] * src[ 0]
        +     datCoeTf16[ 8][ 1] * src[ 1]
        +     datCoeTf16[ 8][ 2] * src[ 2]
        +     datCoeTf16[ 8][ 3] * src[ 3]
        +     datCoeTf16[ 8][ 4] * src[ 4]
        +     datCoeTf16[ 8][ 5] * src[ 5]
        +     datCoeTf16[ 8][ 6] * src[ 6]
        +     datCoeTf16[ 8][ 7] * src[ 7]
        +     datCoeTf16[ 8][ 8] * src[ 8]
        +     datCoeTf16[ 8][ 9] * src[ 9]
        +     datCoeTf16[ 8][10] * src[10]
        +     datCoeTf16[ 8][11] * src[11]
        +     datCoeTf16[ 8][12] * src[12]
        +     datCoeTf16[ 8][13] * src[13]
        +     datCoeTf16[ 8][14] * src[14]
        +     datCoeTf16[ 8][15] * src[15]
    ;
    dst[ 9] = datCoeTf16[ 9][ 0] * src[ 0]
        +     datCoeTf16[ 9][ 1] * src[ 1]
        +     datCoeTf16[ 9][ 2] * src[ 2]
        +     datCoeTf16[ 9][ 3] * src[ 3]
        +     datCoeTf16[ 9][ 4] * src[ 4]
        +     datCoeTf16[ 9][ 5] * src[ 5]
        +     datCoeTf16[ 9][ 6] * src[ 6]
        +     datCoeTf16[ 9][ 7] * src[ 7]
        +     datCoeTf16[ 9][ 8] * src[ 8]
        +     datCoeTf16[ 9][ 9] * src[ 9]
        +     datCoeTf16[ 9][10] * src[10]
        +     datCoeTf16[ 9][11] * src[11]
        +     datCoeTf16[ 9][12] * src[12]
        +     datCoeTf16[ 9][13] * src[13]
        +     datCoeTf16[ 9][14] * src[14]
        +     datCoeTf16[ 9][15] * src[15]
    ;
    dst[10] = datCoeTf16[10][ 0] * src[ 0]
        +     datCoeTf16[10][ 1] * src[ 1]
        +     datCoeTf16[10][ 2] * src[ 2]
        +     datCoeTf16[10][ 3] * src[ 3]
        +     datCoeTf16[10][ 4] * src[ 4]
        +     datCoeTf16[10][ 5] * src[ 5]
        +     datCoeTf16[10][ 6] * src[ 6]
        +     datCoeTf16[10][ 7] * src[ 7]
        +     datCoeTf16[10][ 8] * src[ 8]
        +     datCoeTf16[10][ 9] * src[ 9]
        +     datCoeTf16[10][10] * src[10]
        +     datCoeTf16[10][11] * src[11]
        +     datCoeTf16[10][12] * src[12]
        +     datCoeTf16[10][13] * src[13]
        +     datCoeTf16[10][14] * src[14]
        +     datCoeTf16[10][15] * src[15]
    ;
    dst[11] = datCoeTf16[11][ 0] * src[ 0]
        +     datCoeTf16[11][ 1] * src[ 1]
        +     datCoeTf16[11][ 2] * src[ 2]
        +     datCoeTf16[11][ 3] * src[ 3]
        +     datCoeTf16[11][ 4] * src[ 4]
        +     datCoeTf16[11][ 5] * src[ 5]
        +     datCoeTf16[11][ 6] * src[ 6]
        +     datCoeTf16[11][ 7] * src[ 7]
        +     datCoeTf16[11][ 8] * src[ 8]
        +     datCoeTf16[11][ 9] * src[ 9]
        +     datCoeTf16[11][10] * src[10]
        +     datCoeTf16[11][11] * src[11]
        +     datCoeTf16[11][12] * src[12]
        +     datCoeTf16[11][13] * src[13]
        +     datCoeTf16[11][14] * src[14]
        +     datCoeTf16[11][15] * src[15]
    ;
    dst[12] = datCoeTf16[12][ 0] * src[ 0]
        +     datCoeTf16[12][ 1] * src[ 1]
        +     datCoeTf16[12][ 2] * src[ 2]
        +     datCoeTf16[12][ 3] * src[ 3]
        +     datCoeTf16[12][ 4] * src[ 4]
        +     datCoeTf16[12][ 5] * src[ 5]
        +     datCoeTf16[12][ 6] * src[ 6]
        +     datCoeTf16[12][ 7] * src[ 7]
        +     datCoeTf16[12][ 8] * src[ 8]
        +     datCoeTf16[12][ 9] * src[ 9]
        +     datCoeTf16[12][10] * src[10]
        +     datCoeTf16[12][11] * src[11]
        +     datCoeTf16[12][12] * src[12]
        +     datCoeTf16[12][13] * src[13]
        +     datCoeTf16[12][14] * src[14]
        +     datCoeTf16[12][15] * src[15]
    ;
    dst[13] = datCoeTf16[13][ 0] * src[ 0]
        +     datCoeTf16[13][ 1] * src[ 1]
        +     datCoeTf16[13][ 2] * src[ 2]
        +     datCoeTf16[13][ 3] * src[ 3]
        +     datCoeTf16[13][ 4] * src[ 4]
        +     datCoeTf16[13][ 5] * src[ 5]
        +     datCoeTf16[13][ 6] * src[ 6]
        +     datCoeTf16[13][ 7] * src[ 7]
        +     datCoeTf16[13][ 8] * src[ 8]
        +     datCoeTf16[13][ 9] * src[ 9]
        +     datCoeTf16[13][10] * src[10]
        +     datCoeTf16[13][11] * src[11]
        +     datCoeTf16[13][12] * src[12]
        +     datCoeTf16[13][13] * src[13]
        +     datCoeTf16[13][14] * src[14]
        +     datCoeTf16[13][15] * src[15]
    ;
    dst[14] = datCoeTf16[14][ 0] * src[ 0]
        +     datCoeTf16[14][ 1] * src[ 1]
        +     datCoeTf16[14][ 2] * src[ 2]
        +     datCoeTf16[14][ 3] * src[ 3]
        +     datCoeTf16[14][ 4] * src[ 4]
        +     datCoeTf16[14][ 5] * src[ 5]
        +     datCoeTf16[14][ 6] * src[ 6]
        +     datCoeTf16[14][ 7] * src[ 7]
        +     datCoeTf16[14][ 8] * src[ 8]
        +     datCoeTf16[14][ 9] * src[ 9]
        +     datCoeTf16[14][10] * src[10]
        +     datCoeTf16[14][11] * src[11]
        +     datCoeTf16[14][12] * src[12]
        +     datCoeTf16[14][13] * src[13]
        +     datCoeTf16[14][14] * src[14]
        +     datCoeTf16[14][15] * src[15]
    ;
    dst[15] = datCoeTf16[15][ 0] * src[ 0]
        +     datCoeTf16[15][ 1] * src[ 1]
        +     datCoeTf16[15][ 2] * src[ 2]
        +     datCoeTf16[15][ 3] * src[ 3]
        +     datCoeTf16[15][ 4] * src[ 4]
        +     datCoeTf16[15][ 5] * src[ 5]
        +     datCoeTf16[15][ 6] * src[ 6]
        +     datCoeTf16[15][ 7] * src[ 7]
        +     datCoeTf16[15][ 8] * src[ 8]
        +     datCoeTf16[15][ 9] * src[ 9]
        +     datCoeTf16[15][10] * src[10]
        +     datCoeTf16[15][11] * src[11]
        +     datCoeTf16[15][12] * src[12]
        +     datCoeTf16[15][13] * src[13]
        +     datCoeTf16[15][14] * src[14]
        +     datCoeTf16[15][15] * src[15]
    ;
}

void fwDct16Reuse(const uint8_t src[16], int32_t dst[16])
{    // E and O
    int32_t E[8], O[8];
    for (int i = 0; i < 8; i++) {
        E[i] = src[i] + src[15 - i];
        O[i] = src[i] - src[15 - i];
    }

    // EE and EO
    int32_t EE[4], EO[4];
    for (int i = 0; i < 4; i++) {
        EE[i] = E[i] + E[7 - i];
        EO[i] = E[i] - E[7 - i];
    }

    // EEE and EEO
    int32_t EEE[2], EEO[2];
    EEE[0] = EE[0] + EE[3];
    EEO[0] = EE[0] - EE[3];
    EEE[1] = EE[1] + EE[2];
    EEO[1] = EE[1] - EE[2];

    // EEEE and EEEO
    int32_t EEEE[1], EEEO[1];
    EEEE[0] = EEE[0] + EEE[1];
    EEEO[0] = EEE[0] - EEE[1];

    // M only
    dst[0]  = datCoeTf16[0][0] * EEEE[0];
    dst[8]  = datCoeTf16[8][0] * EEEO[0];

    // MAC 2
    dst[ 4] = datCoeTf16[ 4][0] * EEO[0]
        +     datCoeTf16[ 4][1] * EEO[1]
    ;
    dst[12] = datCoeTf16[12][0] * EEO[0]
        +     datCoeTf16[12][1] * EEO[1]
    ;

    // MAC 4
    for (int j = 2; j < 16; j += 4) {
        dst[j] = datCoeTf16[j][0] * EO[0]
            +    datCoeTf16[j][1] * EO[1]
            +    datCoeTf16[j][2] * EO[2]
            +    datCoeTf16[j][3] * EO[3]
        ;
    }

    // MAC 8
    for (int j = 1; j < 16; j += 2) {
        dst[j] = datCoeTf16[j][0] * O[0]
            +    datCoeTf16[j][1] * O[1]
            +    datCoeTf16[j][2] * O[2]
            +    datCoeTf16[j][3] * O[3]
            +    datCoeTf16[j][4] * O[4]
            +    datCoeTf16[j][5] * O[5]
            +    datCoeTf16[j][6] * O[6]
            +    datCoeTf16[j][7] * O[7]
        ;
    }
}

void fwDct16ReuseUnroll(const uint8_t src[16], int32_t dst[16])
{
    // E and O
    int32_t E[8], O[8];
    E[0] = src[0] + src[15];
    O[0] = src[0] - src[15];
    E[1] = src[1] + src[14];
    O[1] = src[1] - src[14];
    E[2] = src[2] + src[13];
    O[2] = src[2] - src[13];
    E[3] = src[3] + src[12];
    O[3] = src[3] - src[12];
    E[4] = src[4] + src[11];
    O[4] = src[4] - src[11];
    E[5] = src[5] + src[10];
    O[5] = src[5] - src[10];
    E[6] = src[6] + src[ 9];
    O[6] = src[6] - src[ 9];
    E[7] = src[7] + src[ 8];
    O[7] = src[7] - src[ 8];

    // EE and EO
    int32_t EE[4], EO[4];
    EE[0] = E[0] + E[7];
    EO[0] = E[0] - E[7];
    EE[1] = E[1] + E[6];
    EO[1] = E[1] - E[6];
    EE[2] = E[2] + E[5];
    EO[2] = E[2] - E[5];
    EE[3] = E[3] + E[4];
    EO[3] = E[3] - E[4];

    // EEE and EEO
    int32_t EEE[2], EEO[2];
    EEE[0] = EE[0] + EE[3];
    EEO[0] = EE[0] - EE[3];
    EEE[1] = EE[1] + EE[2];
    EEO[1] = EE[1] - EE[2];

    // EEEE and EEEO
    int32_t EEEE[1], EEEO[1];
    EEEE[0] = EEE[0] + EEE[1];
    EEEO[0] = EEE[0] - EEE[1];

    // M only
    dst[0] = datCoeTf16[0][0] * EEEE[0];
    dst[8] = datCoeTf16[8][0] * EEEO[0];

    // MAC 2
    dst[ 4] = datCoeTf16[ 4][0] * EEO[0]
        +     datCoeTf16[ 4][1] * EEO[1]
    ;

    dst[12] = datCoeTf16[12][0] * EEO[0]
        +     datCoeTf16[12][1] * EEO[1]
    ;

    // MAC 4
    dst[ 2] = datCoeTf16[ 2][0] * EO[0]
        +     datCoeTf16[ 2][1] * EO[1]
        +     datCoeTf16[ 2][2] * EO[2]
        +     datCoeTf16[ 2][3] * EO[3]
    ;
    dst[ 6] = datCoeTf16[ 6][0] * EO[0]
        +     datCoeTf16[ 6][1] * EO[1]
        +     datCoeTf16[ 6][2] * EO[2]
        +     datCoeTf16[ 6][3] * EO[3]
    ;
    dst[10] = datCoeTf16[10][0] * EO[0]
        +     datCoeTf16[10][1] * EO[1]
        +     datCoeTf16[10][2] * EO[2]
        +     datCoeTf16[10][3] * EO[3]
    ;
    dst[14] = datCoeTf16[14][0] * EO[0]
        +     datCoeTf16[14][1] * EO[1]
        +     datCoeTf16[14][2] * EO[2]
        +     datCoeTf16[14][3] * EO[3]
    ;

    // MAC 8
    dst[ 1] = datCoeTf16[ 1][0] * O[0]
        +     datCoeTf16[ 1][1] * O[1]
        +     datCoeTf16[ 1][2] * O[2]
        +     datCoeTf16[ 1][3] * O[3]
        +     datCoeTf16[ 1][4] * O[4]
        +     datCoeTf16[ 1][5] * O[5]
        +     datCoeTf16[ 1][6] * O[6]
        +     datCoeTf16[ 1][7] * O[7]
    ;
    dst[ 3] = datCoeTf16[ 3][0] * O[0]
        +     datCoeTf16[ 3][1] * O[1]
        +     datCoeTf16[ 3][2] * O[2]
        +     datCoeTf16[ 3][3] * O[3]
        +     datCoeTf16[ 3][4] * O[4]
        +     datCoeTf16[ 3][5] * O[5]
        +     datCoeTf16[ 3][6] * O[6]
        +     datCoeTf16[ 3][7] * O[7]
    ;
    dst[ 5] = datCoeTf16[ 5][0] * O[0]
        +     datCoeTf16[ 5][1] * O[1]
        +     datCoeTf16[ 5][2] * O[2]
        +     datCoeTf16[ 5][3] * O[3]
        +     datCoeTf16[ 5][4] * O[4]
        +     datCoeTf16[ 5][5] * O[5]
        +     datCoeTf16[ 5][6] * O[6]
        +     datCoeTf16[ 5][7] * O[7]
    ;
    dst[ 7] = datCoeTf16[ 7][0] * O[0]
        +     datCoeTf16[ 7][1] * O[1]
        +     datCoeTf16[ 7][2] * O[2]
        +     datCoeTf16[ 7][3] * O[3]
        +     datCoeTf16[ 7][4] * O[4]
        +     datCoeTf16[ 7][5] * O[5]
        +     datCoeTf16[ 7][6] * O[6]
        +     datCoeTf16[ 7][7] * O[7]
    ;
    dst[ 9] = datCoeTf16[ 9][0] * O[0]
        +     datCoeTf16[ 9][1] * O[1]
        +     datCoeTf16[ 9][2] * O[2]
        +     datCoeTf16[ 9][3] * O[3]
        +     datCoeTf16[ 9][4] * O[4]
        +     datCoeTf16[ 9][5] * O[5]
        +     datCoeTf16[ 9][6] * O[6]
        +     datCoeTf16[ 9][7] * O[7]
    ;
    dst[11] = datCoeTf16[11][0] * O[0]
        +     datCoeTf16[11][1] * O[1]
        +     datCoeTf16[11][2] * O[2]
        +     datCoeTf16[11][3] * O[3]
        +     datCoeTf16[11][4] * O[4]
        +     datCoeTf16[11][5] * O[5]
        +     datCoeTf16[11][6] * O[6]
        +     datCoeTf16[11][7] * O[7]
    ;
    dst[13] = datCoeTf16[13][0] * O[0]
        +     datCoeTf16[13][1] * O[1]
        +     datCoeTf16[13][2] * O[2]
        +     datCoeTf16[13][3] * O[3]
        +     datCoeTf16[13][4] * O[4]
        +     datCoeTf16[13][5] * O[5]
        +     datCoeTf16[13][6] * O[6]
        +     datCoeTf16[13][7] * O[7]
    ;
    dst[15] = datCoeTf16[15][0] * O[0]
        +     datCoeTf16[15][1] * O[1]
        +     datCoeTf16[15][2] * O[2]
        +     datCoeTf16[15][3] * O[3]
        +     datCoeTf16[15][4] * O[4]
        +     datCoeTf16[15][5] * O[5]
        +     datCoeTf16[15][6] * O[6]
        +     datCoeTf16[15][7] * O[7]
    ;
}

int main(int argc, char *argv[]) {
    srand(time(nullptr));
    uint8_t src            [16];
    int32_t dstDirect      [16];
    int32_t dstDirectUnroll[16];
    int32_t dstReuse       [16];
    int32_t dstReuseUnroll [16];
    for (int i = 0; i < 16; ++i)
        src[i] = rand() % 256;
    int id = atoi(argv[1]);
    switch(id) {
    case 0: {
        for (int j = 0; j < 1000; ++j) {
            for (int i = 0; i < 16; ++i)
                src[i] = rand() % 256;
            fwDct16Direct      (src, dstDirect      );
            fwDct16DirectUnroll(src, dstDirectUnroll);
            fwDct16Reuse       (src, dstReuse       );
            fwDct16ReuseUnroll (src, dstReuseUnroll );
            for (int i = 0; i < 16; ++i) {
                if (dstDirectUnroll[i] != dstDirect[i]) {
                    cerr << "error(direct unroll, " << i << ")!" << endl;
                    return 1;
                }
                if (dstReuse[i] != dstDirect[i]) {
                    cerr << "error(reuse, "         << i << ")!" << endl;
                    return 1;
                }
                if (dstReuseUnroll[i] != dstDirect[i]) {
                    cerr << "error(reuse unroll, "  << i << ")!" << endl;
                    return 1;
                }
            }
        }
    break;}
    case 1: {
        for (int j = 0; j < 10 * 1000 * 1000; ++j)
            fwDct16Direct      (src, dstDirect      );
    break;}
    case 2: {
        for (int j = 0; j < 10 * 1000 * 1000; ++j)
            fwDct16DirectUnroll(src, dstDirectUnroll);
    break;}
    case 3: {
        for (int j = 0; j < 10 * 1000 * 1000; ++j)
            fwDct16Reuse       (src, dstReuse       );
    break;}
    case 4: {
        for (int j = 0; j < 10 * 1000 * 1000; ++j)
            fwDct16ReuseUnroll (src, dstReuseUnroll );
    break;}
    }
    return 0;
}
