g++ main.cpp -o main.o
./main.o 0
echo "*** fwDct16Direct       ***"; for i in {1..3}; do { time ./main.o 1; } 2>&1 | grep user; done; echo ""
echo "*** fwDct16DirectUnroll ***"; for i in {1..3}; do { time ./main.o 2; } 2>&1 | grep user; done; echo ""
echo "*** fwDct16Reuse        ***"; for i in {1..3}; do { time ./main.o 3; } 2>&1 | grep user; done; echo ""
echo "*** fwDct16ReuseUnroll  ***"; for i in {1..3}; do { time ./main.o 4; } 2>&1 | grep user; done; echo ""

