%-------------------------------------------------------------------------------
  %
  %  Filename       : L09_WBS.m
  %  Author         : Huang Leilei
  %  Status         : draft
  %  Created        : 2026-09-17
  %  Description    : function to show white block skip
  %
%-------------------------------------------------------------------------------

%% init
clear;
clc;
close all;

%% main body
for strImg = {'TCSVT.jpg', 'TCSVTsub.jpg'}
    % read
    img = imread(strImg{1});
    img = rgb2gray(img);

    % convert
    datThreshold = 200;
    img(img >  datThreshold) = 255;
    img(img <= datThreshold) = 0;
    %imwrite(img, "L09_WBS.png");

    % stats
    numBlack = numel(find(img == 0));
    numWhite = numel(find(img == 255));
    fprintf("percentage of black pixels: %5.2f%%\n", numBlack / (numBlack + numWhite) * 100);
    fprintf("\n");

    % compress
    fprintf("N : percentage\n");
    [sizY, sizX] = size(img);
    for N = [1:9,10:10:90,100:100:900]
        numBin = 0;
        for idxY = 1:sizY
            for idxX = 1:N:sizX
                dat = img(idxY,idxX:min(idxX+N-1,sizX));
                if sum(find(dat == 0)) == 0
                    numBin = numBin + 1;
                else
                    numBin = numBin + 1 + numel(dat);
                end
            end
        end
        fprintf("%-2d: %5.2f%%\n", N, numBin / numel(img) * 100);
    end
    fprintf("\n");
end
