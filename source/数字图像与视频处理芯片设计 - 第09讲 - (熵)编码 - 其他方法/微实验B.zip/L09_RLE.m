%-------------------------------------------------------------------------------
  %
  %  Filename       : L09_RLE.m
  %  Author         : Huang Leilei
  %  Status         : draft
  %  Created        : 2026-09-17
  %  Description    : function to estimate bit number of "run length encoding"
  %
%-------------------------------------------------------------------------------

function numBitAll = L09_RLE(dat, numRunMax, numType)
    numBitAll  = 0;
    numRun  = 0;
    datCode = dat(1);
    for i = 1:numel(dat)
        if dat(i) == datCode
            numRun = numRun + 1;
        end
        if i == numel(dat) || dat(i+1) ~= datCode || numRun == numRunMax
            %if numType ~= 2
            %    numBitAll = numBitAll + ceil(log2(numType));
            %    %fprintf("%d:", datCode);
            %end
            numBitAll = numBitAll + ceil(log2(numType)) + ceil(log2(numRunMax));
            %fprintf("%d\n", numRun);
            if i ~= numel(dat)
                datCode = dat(i + 1);
                numRun = 0;
            end
        end
    end
end
