%-------------------------------------------------------------------------------
  %
  %  Filename       : L09_runRLE.m
  %  Author         : Huang Leilei
  %  Status         : draft
  %  Created        : 2026-09-17
  %  Description    : function to show of "run length encoding"
  %
%-------------------------------------------------------------------------------

% init
clear;
clc;
close all;

% read
img = imread('校园.jpg');
imgSave = rgb2gray(img);

% code 1
img = imgSave;
figure(1);
imshow(imgSave);
img = reshape(img, 1, []);
numBitAll = zeros(1, 6);
for i = 1:8
    numBitAll(i) = L09_RLE(img, 2^i, 256);
    fprintf("%d: %d (%.2f%%)\n", i, numBitAll(i), 100 * numBitAll(i) / (numel(img) * 8));
end
fprintf("\n");

% code 2
img = imgSave;
img(img >= 128) = 255;
img(img <  128) = 0;
figure(2);
imshow(img);
img = reshape(img, 1, []);
numBitAll = zeros(1, 6);
for i = 1:8
    numBitAll(i) = L09_RLE(img, 2^i, 2);
    fprintf("%d: %7d (%.2f%%)\n", i, numBitAll(i), 100 * numBitAll(i) / numel(img));
end
fprintf("\n");

% code 3
img = imgSave;
img = imresize(img, 0.25);
img = imresize(img, 4);
img(img >= 128) = 255;
img(img <  128) = 0;
figure(3);
imshow(img);
img = reshape(img, 1, []);
numBitAll = zeros(1, 6);
for i = 1:8
    numBitAll(i) = L09_RLE(img, 2^i, 2);
    fprintf("%d: %d (%.2f%%)\n", i, numBitAll(i), 100 * numBitAll(i) / numel(img));
end
fprintf("\n");
