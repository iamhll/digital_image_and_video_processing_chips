%-------------------------------------------------------------------------------
  %
  %  Filename       : L10_runHuffmanCodec.m
  %  Author         : Huang Leilei
  %  Status         : draft
  %  Created        : 2026-09-17
  %  Description    : function to show of "Huffman encoding"
  %
%-------------------------------------------------------------------------------

% init
clear;
clc;
close all;
%tic = 1; toc = 1;

% code 0
fprintf("***\n");
datItm = [repmat(0, 1, 8)    ...
    ,     repmat(1, 1, 2)    ...
    ,     repmat(2, 1, 31)   ...
    ,     repmat(3, 1, 16)   ...
    ,     repmat(4, 1, 7)    ...
];
[datBin, map] = L10_HuffmanEnc(datItm, 5, 0);
datItmCodec = L10_HuffmanDec(datBin, map, 5, numel(datItm));
if sum(datItm - datItmCodec) ~= 0
    printf("codec error!\n");
end

% code 1
fprintf("\n");
fprintf("***\n");
datItm = [repmat(0, 1, 19)   ...
    ,     repmat(1, 1, 25)   ...
    ,     repmat(2, 1, 21)   ...
    ,     repmat(3, 1, 16)   ...
    ,     repmat(4, 1, 8)    ...
    ,     repmat(5, 1, 6)    ...
    ,     repmat(6, 1, 3)    ...
    ,     repmat(7, 1, 2)    ...
];
[datBin, map] = L10_HuffmanEnc(datItm, 8, 0);
datItmCodec = L10_HuffmanDec(datBin, map, 8, numel(datItm));
if sum(datItm - datItmCodec) ~= 0
    printf("codec error!\n");
end

% code 2
fprintf("\n");
fprintf("***\n");
datItm = [repmat(0, 1, 999)   ...
    ,     repmat(1, 1, 1)   ...
];
[datBin, map] = L10_HuffmanEnc(datItm, 2, 0);
datItmCodec = L10_HuffmanDec(datBin, map, 2, numel(datItm));
if sum(datItm - datItmCodec) ~= 0
    printf("codec error!\n");
end

% code 3
fprintf("\n");
fprintf("***\n");
datItm = imread('校园.jpg');
datItm = rgb2gray(datItm);
datItm = reshape(datItm, 1, []);
tic; [datBin, map] = L10_HuffmanEnc(datItm, 256, 0); toc;
tic; datItmCodec = L10_HuffmanDec(datBin, map, 256, numel(datItm)); toc;
if sum(double(datItm) - datItmCodec) ~= 0
    fprintf("codec error!\n");
end
