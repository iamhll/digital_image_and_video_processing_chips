%-------------------------------------------------------------------------------
  %
  %  Filename       : L10_runHuffmanCodec.m
  %  Author         : Huang Leilei
  %  Status         : draft
  %  Created        : 2026-09-17
  %  Description    : function to show of "Huffman encoding"
  %
%-------------------------------------------------------------------------------

% init
clear;
clc;
close all;
tic = 1; toc = 1;

% code 1
fprintf("***\n");
datOri = imread('校园.jpg');
datOri = rgb2gray(datOri);
datOri = reshape(datOri, 1, []);
tic; [datBin, map] = L10_HuffmanEnc(datOri, 256, 0); toc;
tic; datItmCodec = L10_HuffmanDec(datBin, map, 256, numel(datOri)); toc;
if sum(double(datOri) - datItmCodec) ~= 0
   fprintf("codec error!\n");
end

% code 2
fprintf("\n");
fprintf("***\n");
datOri = imread('校园.jpg');
datOri = rgb2gray(datOri);
datOri = int16(datOri);
datPre = datOri;
datPre(2:end,1) = datOri(1:end-1,1);
datPre(1,2:end) = datOri(1,1:end-1);
[h, w] = size(datPre);
for i = 2:h
    for j = 2:w
        A = datOri(i-1,j);
        B = datOri(i,j-1);
        C = datOri(i-1,j-1);
        if C < min(A,B)
            datPre(i,j) = max(A,B);
        elseif C >= max(A,B)
            datPre(i,j) = min(A,B);
        else
            datPre(i,j) = A + B - C;
        end
    end
end
datItm = 256 + datOri - datPre;
datItm = reshape(datItm, 1, []);
tic; [datBin, map] = L10_HuffmanEnc(datItm, 512, 0); toc;
tic; datItmCodec = L10_HuffmanDec(datBin, map, 512, numel(datItm)); toc;
if sum(double(datItm) - datItmCodec) ~= 0
    fprintf("codec error!\n");
end
