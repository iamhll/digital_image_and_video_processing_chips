%-------------------------------------------------------------------------------
  %
  %  Filename       : L10_HuffmanDec.m
  %  Author         : Huang Leilei
  %  Status         : draft
  %  Created        : 2026-09-17
  %  Description    : function to do "huffman decoding"
  %
%-------------------------------------------------------------------------------

function [datItm] = L10_HuffmanDec(datBin, map, numSym, sizDat)
    datItm = zeros(1, sizDat);
    idxBin = 1;
    idxItm = 1;
    while idxBin <= numel(datBin)
        idxBinOffset = 0;
        while 1
            datBinCur = datBin(idxBin:idxBin+idxBinOffset);
            idxBinOffset = idxBinOffset + 1;
            idxHit = find(ismember(map, datBinCur));
            if idxHit
                break;
            end
        end
        idxBin = idxBin + idxBinOffset;
        datItm(idxItm) = idxHit - 1;
        idxItm = idxItm + 1;
    end
end


%{
    dat = zeros(1, sizDat);
    idxBin = 1;
    idxDat = 1;
    while idxBin <= numel(bin)
        idxBinOffset = 0;
        idxSchAll = ones(1, numSym);
        while numel(find(idxSchAll)) > 1
            bit = bin(idxBin + idxBinOffset);
            idxBinOffset = idxBinOffset + 1;
            idxSchAllNxt = zeros(1, numSym);
            for idxSch = find(idxSchAll)
                if map{idxSch}(idxBinOffset) == bit
                    idxSchAllNxt(idxSch) = 1;
                end
            end
            idxSchAll = idxSchAllNxt;
        end
        idxBin = idxBin + idxBinOffset;
        dat(idxDat) = find(idxSchAll) - 1;
        idxDat = idxDat + 1;
    end
%}
%{
    dat = zeros(1, sizDat);
    idxBin = 1;
    idxDat = 1;
    while idxBin <= numel(bin)
        idxBinOffset = 0;
        idxSchAll = 1:numSym;
        while numel(idxSchAll) > 1
            bit = bin(idxBin + idxBinOffset);
            idxBinOffset = idxBinOffset + 1;
            idxSchAllNxt = [];
            for idxSch = idxSchAll
                if map{idxSch}(idxBinOffset) == bit
                    idxSchAllNxt = [idxSchAllNxt, idxSch];
                end
            end
            idxSchAll = idxSchAllNxt;
        end
        idxBin = idxBin + idxBinOffset;
        dat(idxDat) = idxSchAll - 1;
        idxDat = idxDat + 1;
    end
%}
