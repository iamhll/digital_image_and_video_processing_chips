%-------------------------------------------------------------------------------
  %
  %  Filename       : L10_HuffmanEnc.m
  %  Author         : Huang Leilei
  %  Status         : draft
  %  Created        : 2026-09-17
  %  Description    : function to do "huffman encoding"
  %
%-------------------------------------------------------------------------------

function [datBin, map] = L10_HuffmanEnc(datItm, numTyp, flgDbg)
    datBin  = [];
    datOdds = zeros(1, numTyp);
    for i = 0:numTyp-1
        datOdds(i + 1) = numel(find(datItm == i));
    end
    H = - sum(datOdds(datOdds~=0)/sum(datOdds) .* log2(datOdds(datOdds~=0)/sum(datOdds)));
    [~, idxSym, map] = L10_HuffmanEncCore(datOdds, flgDbg);
    mapCopy = map;
    for i = 1:numTyp
        map{idxSym(i)} = mapCopy{i};
    end
    for i = 1:numel(datItm)
        datBin = [datBin, map{double(datItm(i)) + 1}];
    end
    numBin = numel(datBin);
    fprintf("H : %.2f\n", H);
    fprintf("CL: %.2f\n", numBin / numel(datItm));
    fprintf("E : %.2f%%\n", H / (numBin / numel(datItm)) * 100);
    fprintf("CR: %.2f\n", numel(datItm) * ceil(log2(numTyp)) / numBin);
end

function [datOdds, idxSym, map] = L10_HuffmanEncCore(datOdds, flgDbg)
    % sort
    [datOdds, idxSym] = sort(datOdds, 'descend');
    %fprintf("%02d ", datOdds);
    %fprintf("\n");
    %fprintf("\n");
    datOddsNxt = datOdds;
    % cat
    datOddsNxt(end - 1) = datOddsNxt(end - 1) + datOddsNxt(end);
    % replace
    datOddsNxt = datOddsNxt(1:end-1);
    % iteration
    if numel(datOdds) > 2
        [datOddsPrv, ~, mapPrv] = L10_HuffmanEncCore(datOddsNxt, flgDbg);
        idxCat = find(datOddsPrv == datOddsNxt(end));
        if numel(idxCat) > 1
            idxCat = idxCat(end);
        end
        mapTmp = mapPrv{idxCat};
        map = mapPrv;
        for i = idxCat:numel(mapPrv)-1
            map{i} = mapPrv{i+1};
        end
        map{end+0} = [mapTmp, '0'];
        map{end+1} = [mapTmp, '1'];
    else
        map{1} = '0';
        map{2} = '1';
    end
    if (flgDbg)
        fprintf("%02d ", datOdds);
        fprintf("\n");
        for i = 1:numel(map)
            fprintf("%s ", map{i});
        end
        fprintf("\n");
        fprintf("\n");
    end
end
